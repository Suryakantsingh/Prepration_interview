package roadmap.monday;


public class BulbSwitcher {

    public int numTimesAllBlue(int[] light) {

        if(light == null || light.length == 0 ){
            return 0;
        }
        int max = light[0];
        int count = 0;


        for (int i = 0; i < light.length; i++) {

            if (light[i] > max) {
                max = light[i];
            }
            if (i + 1 == max) {
                count++;
            }

        }
        return count;
    }

    public static void main(String[] args){

        BulbSwitcher bulb = new BulbSwitcher();
        int[] arr = {4,3,1,2};
        System.out.println(bulb.numTimesAllBlue(arr));
    }
}
