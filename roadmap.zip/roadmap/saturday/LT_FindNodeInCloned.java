package roadmap.saturday;

import sun.reflect.generics.tree.Tree;

import java.util.LinkedList;
import java.util.Queue;

public class LT_FindNodeInCloned {

    TreeNode root;
    static  class TreeNode {

        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int d){
            this.val = d;
            left = right = null;
        }
    }
    public final TreeNode getTargetCopy(final TreeNode original, final TreeNode cloned, final TreeNode target) {

        int count = 0;

        Queue<TreeNode> or = new LinkedList<TreeNode>();
        or.add(original);
        Queue<TreeNode> cl = new LinkedList<TreeNode>();
        cl.add(cloned);

        while(!or.isEmpty() && !cl.isEmpty()){

            int val = 0;
            int length = or.size();
            while(val < length){

                TreeNode temp = or.poll();
                TreeNode temp1 = cl.poll();

                if(temp == target){
                    return temp1;
                }

                if(temp.left != null){
                    or.add(temp.left);
                }
                if(temp1.left != null){
                    cl.add(temp1.left);
                }

                if(temp.right != null){
                    or.add(temp.right);
                }
                if(temp1.right != null){
                    cl.add(temp1.right);
                }

            }
        }
        return null;
    }
    public static void main(String[] args){

        LT_FindNodeInCloned tree = new LT_FindNodeInCloned();
        tree.root = new TreeNode(7);
        tree.root.left = new TreeNode(4);
        tree.root.right = new TreeNode(3);
        tree.root.right.left = new TreeNode(6);
        tree.root.right.right  = new TreeNode(19);

        LT_FindNodeInCloned cloned_tree = new LT_FindNodeInCloned();
        cloned_tree.root = new TreeNode(7);
        cloned_tree.root.left = new TreeNode(4);
        cloned_tree.root.right = new TreeNode(3);
        cloned_tree.root.right.left = new TreeNode(6);
        cloned_tree.root.right.right  = new TreeNode(19);

        LT_FindNodeInCloned value = new LT_FindNodeInCloned();
        System.out.println(value.getTargetCopy(tree.root,cloned_tree.root,tree.root.right).val);



    }
}

