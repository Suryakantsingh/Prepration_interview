package roadmap.sunday;

import java.util.Stack;

public class LT_KthSmallestInTree {

    static TreeNode root;
    static class TreeNode {

        int val;
        TreeNode left, right;

        TreeNode(int data){
            this.val = data;
            left = right = null;
        }
    }

    public int findTheKthSmallest(int k){

        Stack<TreeNode> stack = new Stack();

        while( root != null){
            stack.push(root);
            root = root.left;
        }

        int count  = 1;

        while(!stack.isEmpty()) {

            TreeNode temp = stack.pop();
            if(count == k){
                return temp.val;
            }
            count++;
            if(temp.right != null){
                stack.push(temp.right);
            }


        }
      return -1;
    }

    public static void main(String[] args){

        LT_KthSmallestInTree tree = new LT_KthSmallestInTree();
        root = new TreeNode(2);
        root.left = new TreeNode(1);
        root.right = new TreeNode(4);

        root.right.left = new TreeNode(3);

        System.out.println(tree.findTheKthSmallest(1));

    }
}
