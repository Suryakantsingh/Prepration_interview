package roadmap.saturday;

public class Package_info {
    static {
        System.out.println("This package is created for Leetcode monday roadmap");
    }
}
