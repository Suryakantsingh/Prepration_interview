package roadmap.wednesday;

public class Remove_Duplicate_Sorted_Array {

    public int removeDuplicates(int[] nums) {

        int boxSize = 2;

        if(nums.length < boxSize+1)
            return nums.length;
        int i = boxSize;

        for(int j = boxSize; j < nums.length; j++){
            if(nums[i - boxSize] != nums[j]){
                nums[i++] = nums[j];
            }
        }

        return i;
    }

    public static void main(String[] args) {

        Remove_Duplicate_Sorted_Array remove = new Remove_Duplicate_Sorted_Array();
        int[] arr = {0,0,1,1,1,1,2,3,3};

        System.out.println(remove.removeDuplicates(arr));


    }
}
