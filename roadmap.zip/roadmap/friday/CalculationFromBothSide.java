package roadmap.friday;

public class CalculationFromBothSide {

    public int solve( int[] A, int B ){

        if(B > A.length){
            return 0;
        }
        if(A.length == 2){
            return Math.max(A[0], A[1]);
        }

        int i = B-1;
        int max = 0;
        int front = 0;
        int rear = 0;
        int j = 0;
        int[] val = new int[A.length];
        int[] val1 = new int[A.length];

        while( j <= i){
            max = max + A[j];
            val[j] = max;
            j++;

        }
        front = val[j-1];
        System.out.println("Front : "+front+" : second last : "+A[i]+" val is "+val[j-1]+" value of j : "+j);

        j = A.length-1;
        int limit = A.length-B;
        max = 0;
        int count = 0;
        while( j >= limit){
            max = max + A[j];
            val1[j] = max;
            j--;
            count++;

        }


        rear = val1[j+1];
        System.out.println("Rear : "+rear+" : second last : "+A[i]+" val is "+val[j]+" Count is : "+count);


        int first = 0;
        int back = j+2;
        System.out.println(back);

        max = 0;

        while(first <= j && back <= B-j){

            int sum = val[first]+val1[back];
            if(sum > max){
                max = sum;
            }
            first++;
            back++;
        }
        int max1 = 0;
         j = B-1;
         first = j-1;
         back = A.length-1;

        while(first >=0  && back > j){

            int sum = val[first]+val1[back];
            if(sum > max1){
                max1 = sum;
            }
            first--;
            back--;
        }
        if(max1 > max){
            max = max1;
        }
        if(front > max ){
            if(front > rear){
                return front;
            }else{
                return rear;
            }
        }else{
            if(max > rear){
                return max;
            }else{
                return rear;
            }
        }


    }

    public static void main( String[] args ){

        //int[] arr = {-533, -666, -500, 169, 724, 478, 358, -38, -536, 705, -855, 281, -173, 961, -509, -5, 942, -173, 436, -609, -396, 902, -847, -708, -618, 421, -284, 718, 895, 447, 726, -229, 538, 869, 912, 667, -701, 35, 894, -297, 811, 322, -667, 673, -336, 141, 711, -747, -132, 547, 644, -338, -243, -963, -141, -277, 741, 529, -222, -684, 35};
        //int[] arr = { -533, -666, -500, 169, 724, 478, 358, -38, -536, 705, -855, 281, -173, 961, -509, -5, 942, -173, 436, -609, -39 };
        int[] arr = {5, -2, 3 , 1, 2,-3,4,5,7,9,8};
        CalculationFromBothSide cal = new CalculationFromBothSide();
        System.out.println(cal.solve(arr,5));
    }
}
