package roadmap.tuesday;

import java.util.*;

public class Medium_Lagest_Number {

    public String largestNumber(int[] nums) {

        String result = "";

        List list = new ArrayList();

        for (int i = 0; i < nums.length; i++) {
            list.add(nums[i]);
        }

        Collections.sort(list, new Comparator<Integer>() {

            public int compare(Integer i1, Integer i2) {
                String str = i1.toString();
                String str1 = i2.toString();
                Integer val1 = new Integer(str + str1);
                Integer val2 = new Integer(str1 + str);

                if (val1 < val2) {

                    return 1;
                } else {

                    return -1;
                }
            }
        });

        int count = 0;

        for (int i = 0; i < list.size(); i++) {
            result = result + list.get(i);

            if ((int) list.get(i) == 0) {
                count++;
            }

        }

        return count == result.length() ? "0" : result;
    }

    public static void main(String[] args) {
        int[] nums = {0, 0};
        Medium_Lagest_Number lagest_number = new Medium_Lagest_Number();
        System.out.println(lagest_number.largestNumber(nums));
    }
}
