package roadmap.thursday;

import java.util.ArrayList;
import java.util.Scanner;

public class HC_Fibonacci_Words {

    public static void main( String[] args ){

      //  Scanner sc = new Scanner(System.in);
       // int t = sc.nextInt();

        //for(int i = 0 ; i<t ; i++ ){

            String input1 = "1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679";
            String input2 = "8214808651328230664709384460955058223172535940812848111745028410270193852110555964462294895493038196";
            String n = "104683731294243150";
             try{
                Integer val = new Integer(n);
                System.out.println("Val : " + val);

            ArrayList<String> list = new ArrayList<String>();
            list.add(input1);
            list.add(input2);

            if(input1.length() > val){

                System.out.println("First : "+input1.charAt(val));
            }else{
                if(input2.length() > val){
                    System.out.println("Second : "+input1.charAt(val));

                }else{

                    String str = "";
                    while(true){
                        if(str.length() < val) {
                            str = list.get(0)+list.get(1);
                            list.remove(0);
                            list.add(str);
                            System.out.println("Val in: "+str);
                        }else{
                            System.out.println("Val of : "+str);
                            break;
                        }
                    }
                    if(str.length() > val){
                        System.out.println("Third : "+str.charAt(val-1));
                    }
                }

            }

        }catch (NumberFormatException e){

                 Long val = new Long(n);

                 //System.out.println("Val : " + val);

                 ArrayList<String> list = new ArrayList<String>();
                 list.add(input1);
                 list.add(input2);

                 if(input1.length() > val){
                     int l = 2147483647;
                     while((val) > l){
                        input1 = input1.substring(l);
                        val = val-l;
                     }
                     System.out.println("First : "+input1.charAt(val.intValue()-1));
                 }else{
                     if(input2.length() > val){
                         int l = 2147483647;
                         while((val) > l){
                             input2 = input2.substring(l);
                             val = val-l;
                         }
                         System.out.println("Second : "+input2.charAt(val.intValue()-1));


                     }else{

                         String str = "";
                         while(true){
                             if(str.length() < val) {
                                 str = list.get(0)+list.get(1);
                                 list.remove(0);
                                 list.add(str);

                             }else{
                                 System.out.println("Val of : "+str);
                                 break;
                             }
                         }
                         if(str.length() > val){
                             int l = 2147483647;
                             while(val > l){
                                 str = str.substring(l);
                                 val = val-l;
                             }
                             System.out.println("Third : "+str.charAt(val.intValue()-1));
                         }
                     }

                 }
        }
    }
}
//}
